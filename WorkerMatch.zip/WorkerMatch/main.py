import json
import os
import re

from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup

DATA_FILE = "worker_match_data.json"


class WorkerMatchApp(App):
    def build(self):
        self.title = "WorkerMatch"
        self.workers = []
        self.works = []
        self.load_data()
        return self.make_dashboard()

    def load_data(self):
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.workers = data.get("workers", [])
                self.works = data.get("works", [])
            except Exception:
                self.workers, self.works = [], []

    def save_data(self):
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump({"workers": self.workers, "works": self.works}, f, indent=2)

    def clear(self):
        self.root.clear_widgets()

    def title_label(self, text):
        return Label(text=text, font_size=dp(25), bold=True,
                     size_hint_y=None, height=dp(60))

    def button(self, text, callback, height=56):
        b = Button(text=text, font_size=dp(17), size_hint_y=None,
                   height=dp(height))
        b.bind(on_press=callback)
        return b

    def popup(self, title, message):
        box = BoxLayout(orientation="vertical", padding=dp(15), spacing=dp(10))
        label = Label(text=message, halign="center", valign="middle")
        label.bind(size=lambda inst, val: setattr(inst, "text_size", val))
        close = Button(text="OK", size_hint_y=None, height=dp(50))
        box.add_widget(label)
        box.add_widget(close)
        p = Popup(title=title, content=box, size_hint=(.9, .4))
        close.bind(on_press=p.dismiss)
        p.open()

    def make_dashboard(self, *args):
        layout = BoxLayout(orientation="vertical", padding=dp(16), spacing=dp(10))
        layout.add_widget(self.title_label("👷 WorkerMatch"))
        layout.add_widget(Label(
            text="Find the right worker for the right work",
            size_hint_y=None, height=dp(35), font_size=dp(15)
        ))

        stats = GridLayout(cols=2, spacing=dp(10), size_hint_y=None, height=dp(90))
        stats.add_widget(Label(text=f"👷\n{len(self.workers)}\nWorkers", font_size=dp(16)))
        stats.add_widget(Label(text=f"🛠\n{len(self.works)}\nWorks", font_size=dp(16)))
        layout.add_widget(stats)

        layout.add_widget(self.button("➕ Add Worker", self.add_worker))
        layout.add_widget(self.button("🛠 Add Work", self.add_work))
        layout.add_widget(self.button("🔎 Find Best Worker", self.find_worker))
        layout.add_widget(self.button("👷 View Workers", self.view_workers))
        layout.add_widget(self.button("📋 View Works", self.view_works))
        return layout

    def add_worker(self, *args):
        layout = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(8))
        layout.add_widget(self.title_label("Add Worker"))

        name = TextInput(hint_text="Worker name", multiline=False, size_hint_y=None, height=dp(48))
        phone = TextInput(hint_text="Phone number", multiline=False, size_hint_y=None, height=dp(48))
        location = TextInput(hint_text="Location", multiline=False, size_hint_y=None, height=dp(48))
        skills = TextInput(hint_text="Skills: electrician, wiring, plumbing", multiline=False, size_hint_y=None, height=dp(60))
        experience = TextInput(hint_text="Experience in years", multiline=False, input_filter="int", size_hint_y=None, height=dp(48))
        availability = TextInput(hint_text="Availability", multiline=False, size_hint_y=None, height=dp(48))

        for w in (name, phone, location, skills, experience, availability):
            layout.add_widget(w)

        layout.add_widget(self.button("💾 Save Worker",
            lambda x: self.save_worker(name, phone, location, skills, experience, availability)))
        layout.add_widget(self.button("⬅ Back", self.go_home))
        return layout

    def save_worker(self, name, phone, location, skills, experience, availability):
        if not name.text.strip() or not skills.text.strip():
            self.popup("Missing information", "Please enter the worker name and at least one skill.")
            return

        worker = {
            "id": len(self.workers) + 1,
            "name": name.text.strip(),
            "phone": phone.text.strip(),
            "location": location.text.strip(),
            "skills": self.clean_skills(skills.text),
            "experience": int(experience.text or 0),
            "availability": availability.text.strip() or "Available"
        }
        self.workers.append(worker)
        self.save_data()
        self.popup("Saved", f"{worker['name']} was added successfully.")
        self.go_home()

    def add_work(self, *args):
        layout = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(8))
        layout.add_widget(self.title_label("Add Work"))

        name = TextInput(hint_text="Work name", multiline=False, size_hint_y=None, height=dp(48))
        skills = TextInput(hint_text="Required skills: wiring, electrician", multiline=False, size_hint_y=None, height=dp(60))
        experience = TextInput(hint_text="Required experience in years", multiline=False, input_filter="int", size_hint_y=None, height=dp(48))
        location = TextInput(hint_text="Work location", multiline=False, size_hint_y=None, height=dp(48))

        for w in (name, skills, experience, location):
            layout.add_widget(w)

        layout.add_widget(self.button("💾 Save Work",
            lambda x: self.save_work(name, skills, experience, location)))
        layout.add_widget(self.button("⬅ Back", self.go_home))
        return layout

    def save_work(self, name, skills, experience, location):
        if not name.text.strip() or not skills.text.strip():
            self.popup("Missing information", "Please enter the work name and required skills.")
            return

        work = {
            "id": len(self.works) + 1,
            "name": name.text.strip(),
            "required_skills": self.clean_skills(skills.text),
            "experience": int(experience.text or 0),
            "location": location.text.strip()
        }
        self.works.append(work)
        self.save_data()
        self.popup("Saved", f"{work['name']} was added successfully.")
        self.go_home()

    def clean_skills(self, text):
        text = text.lower().replace("\n", ",").replace(";", ",")
        result = []
        for item in text.split(","):
            item = re.sub(r"[^a-zA-Z0-9 ]", "", item).strip()
            if item:
                result.append(item)
        return list(dict.fromkeys(result))

    def find_worker(self, *args):
        layout = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(8))
        layout.add_widget(self.title_label("Find Best Worker"))

        if not self.works:
            layout.add_widget(Label(text="Add a work first."))
        else:
            for work in self.works:
                layout.add_widget(self.button(
                    f"🔎 {work['name']}",
                    lambda x, w=work: self.show_matches(w)
                ))

        layout.add_widget(self.button("⬅ Back", self.go_home))
        return layout

    def calculate_score(self, worker, work):
        required = set(work["required_skills"])
        available = set(worker["skills"])

        skill_score = 70 * len(required & available) / len(required) if required else 0

        required_exp = work["experience"]
        if required_exp <= 0:
            experience_score = 20
        elif worker["experience"] >= required_exp:
            experience_score = 20
        else:
            experience_score = 20 * worker["experience"] / required_exp

        same_location = (
            bool(work["location"].strip()) and
            worker["location"].strip().lower() == work["location"].strip().lower()
        )
        location_score = 10 if same_location else 0

        return round(min(100, skill_score + experience_score + location_score), 1)

    def show_matches(self, work):
        layout = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(8))
        layout.add_widget(self.title_label("⭐ Best Matches"))

        scroll = ScrollView()
        grid = GridLayout(cols=1, spacing=dp(8), padding=dp(5), size_hint_y=None)
        grid.bind(minimum_height=grid.setter("height"))

        results = [(self.calculate_score(w, work), w) for w in self.workers]
        results.sort(key=lambda x: x[0], reverse=True)

        if not results:
            grid.add_widget(Label(text="No workers added yet.", size_hint_y=None, height=dp(60)))
        else:
            for pos, (score, worker) in enumerate(results[:10], 1):
                medal = "🥇" if pos == 1 else "🥈" if pos == 2 else "🥉" if pos == 3 else f"{pos}."
                grid.add_widget(Label(
                    text=(f"{medal} {worker['name']}\n"
                          f"⭐ Match: {score}%\n"
                          f"Skills: {', '.join(worker['skills'])}\n"
                          f"Experience: {worker['experience']} years\n"
                          f"Location: {worker['location']}\n"
                          f"Availability: {worker['availability']}"),
                    size_hint_y=None, height=dp(125), font_size=dp(14),
                    halign="left", valign="middle"
                ))

        scroll.add_widget(grid)
        layout.add_widget(scroll)
        layout.add_widget(self.button("⬅ Back", self.go_home))
        return layout

    def view_workers(self, *args):
        layout = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(8))
        layout.add_widget(self.title_label("👷 Workers"))
        scroll = ScrollView()
        grid = GridLayout(cols=1, spacing=dp(8), size_hint_y=None)
        grid.bind(minimum_height=grid.setter("height"))

        if not self.workers:
            grid.add_widget(Label(text="No workers added yet.", size_hint_y=None, height=dp(60)))

        for w in self.workers:
            grid.add_widget(Label(
                text=(f"👷 {w['name']}\nPhone: {w['phone']}\n"
                      f"Skills: {', '.join(w['skills'])}\n"
                      f"Experience: {w['experience']} years\n"
                      f"Location: {w['location']}"),
                size_hint_y=None, height=dp(120), halign="left", valign="middle"
            ))

        scroll.add_widget(grid)
        layout.add_widget(scroll)
        layout.add_widget(self.button("⬅ Back", self.go_home))
        return layout

    def view_works(self, *args):
        layout = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(8))
        layout.add_widget(self.title_label("🛠 Works"))
        scroll = ScrollView()
        grid = GridLayout(cols=1, spacing=dp(8), size_hint_y=None)
        grid.bind(minimum_height=grid.setter("height"))

        if not self.works:
            grid.add_widget(Label(text="No works added yet.", size_hint_y=None, height=dp(60)))

        for w in self.works:
            grid.add_widget(Label(
                text=(f"🛠 {w['name']}\n"
                      f"Required skills: {', '.join(w['required_skills'])}\n"
                      f"Experience: {w['experience']} years\n"
                      f"Location: {w['location']}"),
                size_hint_y=None, height=dp(105), halign="left", valign="middle"
            ))

        scroll.add_widget(grid)
        layout.add_widget(scroll)
        layout.add_widget(self.button("⬅ Back", self.go_home))
        return layout

    def go_home(self, *args):
        self.root.clear_widgets()
        self.root.add_widget(self.make_dashboard())


if __name__ == "__main__":
    WorkerMatchApp().run()
