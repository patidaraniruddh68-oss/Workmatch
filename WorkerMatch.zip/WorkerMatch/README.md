# WorkerMatch Prototype

A phone-friendly Kivy prototype for matching workers to work based on skills.

## Features
- Add workers
- Add work requirements
- Skill matching
- Experience matching
- Location matching
- Match percentage
- Local JSON storage

## Build APK
This project is prepared for Buildozer.

From a Linux/Android build environment:
    buildozer -v android debug

The APK will be created in the `bin/` directory.

## Important
This prototype uses local JSON storage. It does not use MySQL yet.
For multiple phones sharing the same data, a Python API + MySQL backend should be added in a later version.
