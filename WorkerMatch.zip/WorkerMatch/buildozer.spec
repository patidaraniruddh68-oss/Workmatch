[app]

title = WorkerMatch
package.name = workermatch
package.domain = org.workermatch

source.dir = .
source.include_exts = py,json,png,jpg,kv

version = 0.1

requirements = python3,kivy

orientation = portrait
fullscreen = 0

android.archs = arm64-v8a

[buildozer]

log_level = 2
warn_on_root = 1
